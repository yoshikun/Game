#! /bin/bash

#rsync -av test_assets/ root@61.147.80.140:/data/ysfzCdn/gameMD5/ --exclude '.svn'
rsync -av test_assets/ root@127.0.0.1:/data/htdocs/cdn --exclude '.svn'
