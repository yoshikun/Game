#! /bin/bash
#DATE=`date '+%Y%m%d'`
echo "请输入主文件版本号"
read DATE
rsync -av test/Main.swf root@127.0.0.1:/data/htdocs/cdn/main/$DATE.swf --exclude '.svn'
